import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CropService {
  public isUserLogged : boolean;

  constructor(public httpClient : HttpClient ) { 
    
 this.isUserLogged = false; 
  }


public setUserLoggedIn():any{
  this.isUserLogged = true;
}

public getUserLogged():any{
  return this.isUserLogged;
}

public setUserLoggedOut():any{
 this.isUserLogged = false;

}
register(regform : any):any{
  return this.httpClient.post('registerFarmer/', regform);


}
getCredentials(mobile:any,password: any):any{
  return this.httpClient.post('getFarmerDetails/', + mobile +'/' +password);
}

}