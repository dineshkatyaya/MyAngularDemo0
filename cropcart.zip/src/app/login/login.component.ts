import { Component, OnInit } from '@angular/core';
import { Router, Routes } from '@angular/router';
import { CropService } from '../crop.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any;
  // employee : any;
  alert: boolean = false;

  constructor(public router: Router, public service: CropService) { }

  ngOnInit(): void {
  }
  closeAlert() {
    this.alert = false;
  }
   submitLoginForm(loginForm: any) {


    if (loginForm.mobile === '9876543210' && loginForm.password === 'Farmer') {
      this.alert = true;
    }
    else {
       this.service.getCredentials(loginForm.mobile, loginForm.password).subscribe((data: any) => { this.user = data; (console.log(data)) });
      /*if (this.user.mobile) {
        this.alert = true;
      }*/
      console.log("Connection Established ");
    }
  }

  register() {
    this.service.setUserLoggedIn();
    this.router.navigate(['register'])
  }



  // }
}
