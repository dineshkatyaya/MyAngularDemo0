import { Component, OnInit } from '@angular/core';
import { CropService } from '../crop.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  alert :boolean = false;
  constructor( public cropService : CropService ) {
   
   }

  ngOnInit(): void {
  }
  registerUser(regForm : any){
    this.alert =true;
    this.cropService.register(regForm).subscribe((result : any) => console.log(result));
 

  }
  closeAlert(){
    this.alert=false;
  }

}
